/*****************************************************************************
*                                                                            *
*  ex-1.c                                                                    *
*  ======                                                                    *
*                                                                            *
*  Opis: Ilustracja u�ycia zbior�w (rozdzia� 7.)                             *
*                                                                            *
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "set.h"

/*****************************************************************************
*                                                                            *
*  ------------------------------- print_set ------------------------------  *
*                                                                            *
*****************************************************************************/

static void print_set(const Set *set) {

ListElmt           *member;

int                *data,
                   size,
                   i;

/*****************************************************************************
*                                                                            *
*  Prezentacja zbioru.                                                       *
*                                                                            *
*****************************************************************************/

fprintf(stdout, "Rozmiar zbioru to %d\n", size = set_size(set));

i = 0;
member = list_head(set);

while (i < size) {

   data = list_data(member);
   fprintf(stdout, "set[%03d]=%03d\n", i, *data);
   member = list_next(member);
   i++;

}

return;

}

/*****************************************************************************
*                                                                            *
*  ------------------------------- match_int ------------------------------  *
*                                                                            *
*****************************************************************************/

static int match_int(const void *key1, const void *key2) {

/*****************************************************************************
*                                                                            *
*  Sprawdzenie, czy dwie liczby ca�kowite pasuj� do siebie.                  *
*                                                                            *
*****************************************************************************/

return !memcmp(key1, key2, sizeof(int));

}

/*****************************************************************************
*                                                                            *
*  --------------------------------- main ---------------------------------  *
*                                                                            *
*****************************************************************************/

int main(int argc, char **argv) {

Set                set,
                   set1,
                   set2;

int                *data,
                   retval,
                   i;

/*****************************************************************************
*                                                                            *
*  Inicjalizacja zbioru.                                                     *
*                                                                            *
*****************************************************************************/

set_init(&set, match_int, free);

/*****************************************************************************
*                                                                            *
*  Wykonanie operacji na zbiorze.                                            *
*                                                                            *
*****************************************************************************/

fprintf(stdout, "Wstawienie 10 element�w.\n");

for (i = 9; i >= 0; i--) {

   if ((data = (int *)malloc(sizeof(int))) == NULL)
      return 1;

   *data = i + 1;

   if ((retval = set_insert(&set, data)) < 0)
      return 1;
   else if (retval == 1)
      free(data);

}

print_set(&set);

fprintf(stdout, "Wstawienie takich samych element�w\n");

for (i = 9; i >= 0; i--) {

   if ((data = (int *)malloc(sizeof(int))) == NULL)
      return 1;

   *data = i + 1;

   if ((retval = set_insert(&set, data)) < 0)
      return 1;
   else if (retval == 1)
      free(data);

}

print_set(&set);

fprintf(stdout, "Wstawianie 200 i 100\n");

if ((data = (int *)malloc(sizeof(int))) == NULL)
   return 1;

*data = 200;

if ((retval = set_insert(&set, data)) < 0)
   return 1;
else if (retval == 1)
   free(data);

if ((data = (int *)malloc(sizeof(int))) == NULL)
   return 1;

*data = 100;

if ((retval = set_insert(&set, data)) < 0)
   return 1;
else if (retval == 1)
   free(data);

print_set(&set);

fprintf(stdout, "Usuwanie 100, 5 i 10\n");

i = 100;
data = &i;

if (set_remove(&set, (void **)&data) == 0)
   free(data);

i = 5;
data = &i;

if (set_remove(&set, (void **)&data) == 0)
   free(data);

i = 10;
data = &i;

if (set_remove(&set, (void **)&data) == 0)
   free(data);

print_set(&set);

fprintf(stdout, "Usuwanie trzech element�w\n");

if (list_rem_next(&set, NULL, (void **)&data) == 0)
   free(data);

if (list_rem_next(&set, NULL, (void **)&data) == 0)
   free(data);

if (list_rem_next(&set, NULL, (void **)&data) == 0)
   free(data);

print_set(&set);

fprintf(stdout, "Usuwanie wszystkich element�w\n");

while (set_size(&set) > 0) {

   if (list_rem_next(&set, NULL, (void **)&data) == 0)
      free(data);
   
}

print_set(&set);

/*****************************************************************************
*                                                                            *
*  Inicjalizacja dw�ch zbior�w.                                              *
*                                                                            *
*****************************************************************************/

set_init(&set1, match_int, free);
set_init(&set2, match_int, free);

/*****************************************************************************
*                                                                            *
*  Wykonywanie operacji na zbiorach.                                         *
*                                                                            *
*****************************************************************************/

for (i = 9; i >= 0; i--) {

   if ((data = (int *)malloc(sizeof(int))) == NULL)
      return 1;

   *data = i + 1;

   if ((retval = set_insert(&set1, data)) < 0)
      return 1;
   else if (retval == 1)
      free(data);

   if (i == 5 || i == 6 || i == 7) {

      if ((data = (int *)malloc(sizeof(int))) == NULL)
         return 1;

      *data = i * 10;

      if ((retval = set_insert(&set2, data)) < 0)
         return 1;
      else if (retval == 1)
         free(data);

      }

   else if (i == 3 || i == 1) {

      if ((data = (int *)malloc(sizeof(int))) == NULL)
         return 1;

      *data = i;

      if ((retval = set_insert(&set2, data)) < 0)
         return 1;
      else if (retval == 1)
         free(data);

   }

}

fprintf(stdout, "Zbi�r 1 do testowania sum, przeci�ci i r�nic\n");
print_set(&set1);
fprintf(stdout, "Zbi�r 2 do testowania sum, przeci�ci i r�nic\n");
print_set(&set2);

fprintf(stdout, "Okre�lenie sumy dw�ch zbior�w\n");

if (set_union(&set, &set1, &set2) != 0)
   return 1;

print_set(&set);

fprintf(stdout, "Usuni�cie sumy\n");
set_destroy(&set);

fprintf(stdout, "Okre�lenie przeci�cia dw�ch zbior�w\n");

if (set_intersection(&set, &set1, &set2) != 0)
   return 1;

print_set(&set);

fprintf(stdout, "Sprawdzenie, czy przeci�cie r�wne jest zbiorowi 1...Warto��=%d "
   "(0=OK)\n", set_is_equal(&set, &set1));

fprintf(stdout, "Sprawdzenie, czy zbi�r 1 jest r�wny samemu sobie...Warto��=%d (1=OK)\n",
   set_is_equal(&set1, &set1));

fprintf(stdout, "Sprawdzenie, czy przeci�cie jest podzbiorem zbioru 1..."
   "Warto��=%d (1=OK)\n", set_is_subset(&set, &set1));

fprintf(stdout, "Sprawdzenie, czy zbi�r 2 jest podzbiorem zbioru 1...Warto��=%d "
   "(0=OK)\n", set_is_subset(&set2, &set1));

fprintf(stdout, "Usuwanie przeci�cia\n");
set_destroy(&set);

fprintf(stdout, "Okre�lenie r�nicy dw�ch zbior�w\n");

if (set_difference(&set, &set1, &set2) != 0)
   return 1;

print_set(&set);

i = 3;
fprintf(stdout, "Sprawdzanie, czy %03d nale�y do r�nicy...Warto��=%d (0=OK)\n",i,
   set_is_member(&set, &i));

i = 5;
fprintf(stdout, "Sprawdzanie, czy %03d nale�y do r�nicy...Warto��=%d (1=OK)\n",i,
   set_is_member(&set, &i));

/*****************************************************************************
*                                                                            *
*  Usuni�cie zbior�w.                                                        *
*                                                                            *
*****************************************************************************/

fprintf(stdout, "Usuwanie zbior�w\n");
set_destroy(&set);
set_destroy(&set1);
set_destroy(&set2);

return 0;

}
