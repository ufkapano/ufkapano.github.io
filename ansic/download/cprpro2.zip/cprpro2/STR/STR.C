/*-*/
/********************************************************
 * Nazwa:						              * 
 *	string						        *
 *							              *
 * Cel:						              *
 *	Demonstracja funkcji strcpy (kopiujacej lancuchy) *
 *							              *  
 * Zastosowanie:						        *
 * 	Uruchom program i odszukaj lancuch "Piotr"	  *
 ********************************************************/
/*+*/
#include <string.h>
#include <stdio.h>
char name[30];    /* imie osoby */
int main()
{
    strcpy(name, "Piotr");    /* inicjalizacja zmiennej name */
    printf("Imie brzmi %s\n", name);
    return (0);
}
