/*-*/
/********************************************************
 * Nazwa: Accuracy					        *
 *							              *
 * Cel: Okresla dokladnosc liczb zmiennoprzecinkowych	  *
 *	zapisanych w pamieci i wykorzystywanych w         * 
 *    obliczeniach.	                                * 
 *							              *
 * Zastosowanie: Po uruchomieniu sprawdz wyniki.	  *
 *						 	              *
 * Uwagi: Istnieje o wiele wiecej precyzyjniejszych 	  *
 *	    matematycznych metod okreslania dokladnosci.  *
 ********************************************************/
/*+*/
#include <stdio.h>
int main()
{
    /* dwie przetwarzane liczby */
    float number1, number2;
    float result;               /* wynik obliczen */
    int   counter;              /* licznik petli oraz kontrola dokladnosci */

    number1 = 1.0;
    number2 = 1.0;
    counter = 0;

    while (number1 + number2 != number1) {
        ++counter;
        number2 = number2 / 10.0;
    }
    printf("%2d cyfrowa dokladnosc obliczen\n", counter);

    number2 = 1.0;
    counter = 0;

    while (1) {
        result = number1 + number2;
        if (result == number1)
            break;
        ++counter;
        number2 = number2 / 10.0;
    }
    printf("%2d cyfrowa dokladnosc liczb przechowywanych w pamieci\n", counter);
    return (0);
}
