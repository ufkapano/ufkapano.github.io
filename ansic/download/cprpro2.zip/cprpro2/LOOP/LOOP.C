/*-*/
/**********************************************************
 * Pytanie: Dlaczego program wykonuje petle nieskonczona? *
 **********************************************************/
/*+*/
#include <stdio.h>
int main()
{
    short int i;	/* licznik petli */
    signed char ch;	/* licznik petli innego typu */

    /* dziala poprawnie */
    for (i = 0x80; i != 0; i = (i >> 1)) {
	printf("Licznik i jest rowny %x (%d)\n", i, i);
    }

    /* nie dziala poprawnie */
    for (ch = 0x80; ch != 0; ch = (ch >> 1)) {
	printf("Licznik ch jest rowny %x (%d)\n", ch, ch);
    }
    return (0);
}
