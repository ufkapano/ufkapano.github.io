/*-*/
/************************************************************
 * Nazwa: Double						            *
 *							                  * 
 * Cel: Wyswietla liczby i ich dwukrotnosc.	            *
 *							                  *
 * Zastosowanie: Aby uzyskac tabele zawierajaca dwukrotnosc *
 * liczb uruchom program.			                  *
 ************************************************************/
/*+*/
#define SIZE 20    /* operuje na 20 elementach */

int data[SIZE];    /* okreslone dane */
int twice[SIZE];   /* dwukrotna ilosc danych */

int main()
{
    int index;   /* indeks danych */

    for (index = 0; index < SIZE; ++index) {
	data[index] = index;
	twice[index] = index * 2;
    }
    return (0);
}
