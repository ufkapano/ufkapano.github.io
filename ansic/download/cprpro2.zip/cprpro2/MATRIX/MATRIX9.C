/*-*/
/************************************************************
 * Pytanie:						                  *
 *	Dlaczego funkcja memset z powodzeniem inicjalizuje	*
 *	macierz o wartosciach -1, ale gdy probujemy ustawic   *
 *    dla kazdego jej elementu wartosc 1, to sie nie udaje? *
 ************************************************************/
/*+*/
#define X_SIZE 60
#define Y_SIZE 30

int matrix[X_SIZE][Y_SIZE];

#define init_matrix() \
    memset(matrix, 1, sizeof(matrix));
