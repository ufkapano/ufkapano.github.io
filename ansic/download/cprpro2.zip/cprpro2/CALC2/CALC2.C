/*-*/
/********************************************************
 * Nazwa: Calculator (Wersja 1)		              *
 *							              *
 * Cel:						              *
 *	Dziala podobnie jak kalkulator 4-funkcyjny.	  *
 *							              *  
 * Zastosowanie:						        *
 *	Uruchom program.				              *
 *	Wprowadz operator (+ - * /) i liczbe.	        *
 *	Operacja zostanie wykonana na aktualnym wyniku,	  *
 *	po czym zostanie wyswietlony nowy wynik.		  *
 *							              *
 *	Aby zamknac program nalezy wprowadzic znak 'Q'.   *
 ********************************************************/
/*+*/
#include <stdio.h>
char  line[100];/* zmienna przechowujaca dane wejsciowe */

int   result;   /* wynik obliczen */
char  operator; /* operator podany przez uzytkownika */
int   value;    /* wartosc podana za operatorem */

int main()
{
    result = 0; /* inicjalizacja zmiennej result */

    /* petla wykonywana w nieskonczonosc */
    /* (lub do momentu wykonania instrukcji break) */
    while (1) {
        printf("Wynik: %d\n", result);
        printf("Podaj operator i liczbe: ");
        fgets(line, sizeof(line), stdin);
        sscanf(line, "%c %d", &operator, &value);

        if ((operator == 'q') || (operator == 'Q'))
            break;

        if (operator == '+') {
            result += value;
        } else if (operator == '-') {
            result -= value;
        } else if (operator == '*') {
            result *= value;
        } else if (operator == '/') {
            if (value == 0) {
                printf("B��d:Proba dzielenia przez zero\n");
                printf("   operacja zignorowana\n");
            } else
                result /= value;
        } else {
            printf("Nieprawidlowy typ operatora %c\n", operator);
        }
    }
    return (0);
}
