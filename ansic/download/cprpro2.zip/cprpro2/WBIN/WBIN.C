/*-*/
/**************************************************************
 * Pytanie:						                    *
 *	Funkcja fputc moze byc zastosowana do	              *
 *	zapisania pojedynczego bajta pliku		              *
 *	binarnego.  Ponizszy program zapisuje liczby		  *
 *	od 0 do 127 w pliku o nazwie		                    *
 *	test.out.  Dziala prawidlowo pod systemem		        *
 *	UNIX, gdzie tworzy plik o dlugosci 128 bajtow,		  *
 *	natomiast pod systemem DOS utworzony plik ma dlugosc    *
 *	129 bajtow. Czym jest to spowodowane?		   	  *
 **************************************************************/
/*+*/
#include <stdio.h>
#include <stdlib.h>	
#ifndef __MSDOS__
#include <unistd.h>
#endif __MSDOS__

int main()
{
    int cur_char;   /* aktualnie zapisywany znak */
    FILE *out_file; /* plik wyjsciowy */

    out_file = fopen("test.out", "w");
    if (out_file == NULL) {
        fprintf(stderr,"Nie mozna otworzyc pliku wyjsciowego\n");
        exit (8);
    }

    for (cur_char = 0; cur_char < 128; ++cur_char) {
        fputc(cur_char, out_file);
    }
    fclose(out_file);
    return (0);
}
