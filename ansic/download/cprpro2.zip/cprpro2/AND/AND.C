#include <stdio.h>
int main()
{
    int i1, i2;	/* dwie losowe liczby calkowite */

    i1 = 4;
    i2 = 2;

    /* Zalecany sposob pisania instrukcji warunkowej */
    if ((i1 != 0) && (i2 != 0))
	printf("Obie liczby sa rozne od zera\n");

    /* Krotszy sposob zapisania powyzszej instrukcji */
    /* Kod skladniowo poprawny, ale styl nie zalecany */
    if (i1 && i2)
	printf("Obie liczby sa rozne od zera\n");

    /* Nieprawidlowe uzycie operatora bitowego jest przyczyna bledu */
    if (i1 & i2)
	printf("Obie liczby sa rozne od zera\n");

    return (0);
}
