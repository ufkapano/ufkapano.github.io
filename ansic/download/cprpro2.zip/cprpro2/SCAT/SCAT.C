/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego ponizszy program wyswietla zamiast	  *
 *	lancucha John Doe lancuch "John @#$24"?		  *
 *	(Uzyskane wyniki moga sie roznic.)			  *
 ********************************************************/
/*+*/
#include <stdio.h>
#include <string.h>

char first[100];	        /* Imie osoby */
char last[100];		/* Nazwisko osoby */

/* Polaczone imie i nazwisko */
char full[100];

int main() {
    strcpy(first, "John");
    strcpy(last, "Doe");

    strcpy(full, first);
    strcat(full, ' ');
    strcat(full, last);

    printf("Osoba nazywa sie %s\n", full);
    return (0);
}
