/*-*/
/**********************************************************
 * Nazwa: Divide error.					          *
 *							                *
 * Program zawiera blad, ktory w efekcie wywoluje	    *
 * blad dzielenia przez zero.					    *
 * 							                *
 * Jednak wskutek zastosowanego buforowania komunikat     *
 * "Przed operacja dzielenia..." moze nie zostac wyswietlony. *
 *							                *
 * Uwaga: Nie nasladuj tego typu kodowania.		    *
 **********************************************************/
/*+*/
#include <stdio.h>
int main()
{
    int i,j;    /* dwie losowe liczby calkowite */

    i = 1;
    j = 0;
    printf("Poczatek\n");
    printf("Przed operacja dzielenia...");
    i = i / j;  /* blad dzielenia przez zero */
    printf("Koniec\n");
    return(0);
}
