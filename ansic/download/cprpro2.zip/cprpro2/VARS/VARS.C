/*-*/
/********************************************************
 * Nazwa: Variable Demo					        *
 *							              *
 * Cel: Demonstracja zastosowania pamieci trwalej i	  *
 *		tymczasowej			                    *
 *							              *
 * Zastosowanie: Po uruchomieniu programu sprawdz       *
 *               wyniki, a nastepnie zanalizuj kod.     *
 ********************************************************/
/*+*/
#include <stdio.h>

int main() {
    int counter;    /* licznik petli */
    for (counter = 0; counter < 3; ++counter) {
        int temporary = 1;	  /* zmienna tymczasowa */
        static int permanent = 1; /* zmienna stala */

        printf("Wartosc tymczasowa %d Wartosc stala %d\n",
            temporary, permanent);
        ++temporary;
        ++permanent;
    }
    return (0);
}
