/*-*/
/*********************************************************
 * Pytanie: Kompilacja ponizszego programu nie jest	   *
 * mozliwa, poniewaz nie zdefiniowano zmiennej "number". *
 * Zmienna "number" jest parametrem makra, a zatem       *
 * nie powinna byc definiowana. O co w tym chodzi?	   *
 *********************************************************/
/*+*/
#include <stdio.h>
#define RECIPROCAL (number) (1.0 / (number))

int main()
{
    float   counter;	/* licznik tabeli */

    for (counter = 0.0; counter < 10.0; 
	 counter += 1.0) {

        printf("1/%f = %f\n", 
	       counter, RECIPROCAL(counter));
    }
    return (0);
}
