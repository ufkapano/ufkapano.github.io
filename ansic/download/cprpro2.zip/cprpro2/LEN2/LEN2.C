/*-*/
/********************************************************
 * Odpowiedz na pytanie 9.1.				        *
 *							              *
 * Aby uzyskac szczegolowe informacje nalezy zajrzec    *
 * do ksiazki.			                          *
 ********************************************************/
/*+*/
#include <stdio.h>

int  length(char string[])
{
    int             index;      /* indeks wewnatrz lancucha */

    /*
     * Petla jest wykonywana do momentu osiagniecia konca lancucha
     */
    for (index = 0; string[index] != '\0'; ++index)
        continue; /* nic nie robi */
    return (index);
}

int main()
{
     char line[100];	/* dane wprowadzone przez uzytkownika */

     while (1) {
        printf("Wpisz tekst:");
        fgets(line, sizeof(line), stdin);

	printf("Dlugosc wynosi (lacznie ze znakiem nowego wiersza) : %d\n", length(line));
    }
}
