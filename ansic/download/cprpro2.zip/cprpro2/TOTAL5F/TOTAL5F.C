/*-*/
/**********************************************************
 * Program: ADD5 -- Dodaje 5 liczb.			          *
 *							                *
 * Zastosowanie:						          *
 *	Po uruchomieniu programu wprowadz 5 liczb, a        *
 *    zostanie wyznaczona ich suma.	                      *
 *							                *
 * Uwaga: Program jest identyczny jak w przykladzie 8.1   *
 *	poza tym, ze zamiast petli while stosuje petle for. *
 **********************************************************/
/*+*/
#include <stdio.h>

int total;      /* suma wszystkich liczb */
int current;    /* aktualna wartosc podana przez uzytkownika */
int counter;    /* licznik petli while */

char line[80];  /* zmienna przechowujaca dane wejsciowe */

int main() {
    total = 0;
    for (counter = 0; counter < 5; ++counter) {
        printf("Jaka liczba? ");

        fgets(line, sizeof(line), stdin);
        sscanf(line, "%d", &current);
        total += current;
    }
    printf("Suma calkowita wynosi: %d\n", total);
    return (0);
}
