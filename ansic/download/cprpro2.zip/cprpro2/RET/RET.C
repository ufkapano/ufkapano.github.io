#include <stdio.h>

int main()
{
    /* pobiera kwadrat liczby */
    int i = square(5);

    printf("i ma wartosc %d\n", i);
    return (0);
}

float square(s)
int s;
{
    return (s * s);
}
