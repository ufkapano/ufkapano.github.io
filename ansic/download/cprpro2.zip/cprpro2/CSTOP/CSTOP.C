/*-*/
/********************************************************
 * point_color --  pobiera kolor pojedynczego punktu	  *
 *							              *
 * Parametry						        * 
 *	point_number -- indeks punktu		              *
 *							              *
 * Wartosc zwracana						  *
 *	Format RGB koloru.			              *
 ********************************************************/
/*+*/
extern float lookup(int index);

float point_color(int point_number)
{
    float correction;  /* wspolczynnik korekcji koloru */
    extern float red,green,blue;/* aktualnie wybrane kolory */

    correction = lookup(point_number);
    return (red*correction * 100.0 + 
            blue*correction * 10.0 +
            green*correction);
}
