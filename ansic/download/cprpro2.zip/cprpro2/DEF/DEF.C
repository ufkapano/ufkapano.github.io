/*-*/
/*************************************************************
 * Pytanie:						                   *
 *	Dlaczego ponizszy program *nie* wyswietla	             *
 *	po wprowadzeniu niepoprawnego polecenie 	             *
 *	komunikatu bledu?  Wskazowka:  Zastosowanie instrukcji *
 *	skoku *goto* z pewnego powodu ma sens.			 *
 *************************************************************/
/*+*/
#include <stdio.h>
#include <stdlib.h>		

int main()
{
    char  line[10];

    while (1) {
	printf("Wpisz jedno z polecen: add(a), delete(d), quit(q): ");
	fgets(line, sizeof(line), stdin);

	switch (line[0]) {
	case 'a':
	    printf("Polecenie add\n");
	    break;
	case 'd':
	    printf("Polecenie delete\n");
	    break;
	case 'q':
	    printf("Polecenie quit\n");
	    exit(0);
        defualt:
	    printf("Blad:Niepoprawne polecenie %c\n", line[0]);
	    break;
	}
    }
}
