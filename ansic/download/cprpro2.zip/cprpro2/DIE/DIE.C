#include <stdio.h>
#include <stdlib.h>	

#define DIE \
  fprintf(stderr, "Blad krytyczny: Zatrzymanie\n");exit(8); 

int main() {     
    /* wartosc losowa dla celow testowych */
    int value;  
    
    value = 1; 
    if (value < 0) 
        DIE; 

    printf("To jeszcze nie koniec\n");
    return (0);
} 
