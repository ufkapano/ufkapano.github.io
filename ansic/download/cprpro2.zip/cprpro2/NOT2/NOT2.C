/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego ponizszy program uwaza, ze		        *
 *	wszystko jest rowne 2?  				  *
 ********************************************************/
/*+*/
#include <stdio.h>
int main()
{
    char line[80];
    int number;

    printf("Podaj liczbe: ");

    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d", &number);

    if (number =! 2) 
	printf("Liczba nie jest rowna 2\n");
    else
	printf("Liczba jest rowna 2\n");

    return (0);
}
