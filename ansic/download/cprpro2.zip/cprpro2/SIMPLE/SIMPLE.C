/*-*/
/********************************************************
 * Nazwa:						              *
 *	Very Simple					              *
 * 							              *
 * Cel:						              *
 *	Bardzo prosta prezentacja wyrazen arytmetycznych. *
 *							              *
 * Uwagi:						              *
 * 	Pomimo, ze program wyznacza wartosc nie	        *
 *	wyswietla jej, dlatego tez jest on malo  	        *
 *	przydatny do celow demonstracyjnych.	        *
 *					                          *
 ********************************************************/
/*+*/
int main()
{
    (1 + 2) * 4;
    return (0);
}
