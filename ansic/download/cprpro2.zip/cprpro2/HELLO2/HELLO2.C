/********************************************************
 * hello -- program wyswietlajcy komunikat              * 
 *          "Witaj swiecie".                            *
 *       Nie jest to szczegolnie ambitny program.       *
 *                                                      *
 * Autor:  Steve Oualline                               *
 *                                                      *
 * Cel:    Prezentacja przykladowego programu           *
 *                                                      *
 * Zastosowanie:                                        *
 *      Po uruchomieniu programu zostanie wyswietlony   *
 *      komunikat.                                      *
 ********************************************************/
#include <stdio.h>

int main()
{
    /* Powiedz: Witaj swiecie */
    printf("Witaj swiecie\n");
    return (0);
}
