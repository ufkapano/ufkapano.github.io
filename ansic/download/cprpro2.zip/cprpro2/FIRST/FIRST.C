/*-*/
/********************************************************
 * Pytanie: Dlaczego program twierdzi, ze wynik ma 	  *
 *	wartosc 47, podczas gdy my jestesmy przekonani,   *
 *	ze jest to liczba 144?					  *
 ********************************************************/
/*+*/
#include <stdio.h>

#define FIRST_PART      7 
#define LAST_PART       5 
#define ALL_PARTS       FIRST_PART + LAST_PART 

int main() { 
    printf("Kwadrat obu czesci ma wartosc: %d\n", 
	ALL_PARTS * ALL_PARTS); 
    return (0);
} 
