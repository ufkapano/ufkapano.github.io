/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dla danej szerokosci i wysokosci program wyznacza *
 *    pole trojkata.		                          *
 *							              *
 * Z jakiegos nieznanego powodu, kompilator nie uznaje  * 
 * faktu deklaracji zmiennej width.	                    *
 *							              *
 * Deklaracja zmiennej znajduje sie w wierszu 16,	  *
 * zaraz ponizej deklaracji zmiennej height.  		  *
 * Dlaczego kompilator nie widzi zmiennej?		  *
 ********************************************************/
/*+*/
#include <stdio.h>
char line[100];  /* wprowadzone dane */
int  height;     /* wysokosc trojkata
int  width;      /* szerokosc trojkata */
int  area;       /* pole powierzchni trojkata (obliczone) */

int main()
{
    printf("Podaj szerokosc i wysokosc. ");

    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d %d", &width, &height);

    area = (width * height) / 2;
    printf("Pole powierzchni wynosi %d\n", area);
    return (0);
}
