/*-*/
/********************************************************
 * Nazwa:						              *
 *	Fibonacci					              *
 *							              *
 * Cel:						              *
 *	Wyswietla wartosci ciagu Fibonacciego		  *
 *							              *
 * Zastosowanie:						        *
 *	Uruchom program, ktory wyswietli wszystkie        *
 *    wartosci ponizej liczby 100				  *
 ********************************************************/
/*+*/
#include <stdio.h>
int   old_number;     /* poprzednia wartosc ciagu Fibonacciego */
int   current_number; /* aktualna wartosc ciagu Fibonacciego */
int   next_number;    /* nastepna wartosc ciagu */

int main()
{
    /* poczatek programu */
    old_number = 1;
    current_number = 1;

    printf("1\n");    /* Wyswietla pierwsza wartosc ciagu */

    while (current_number < 100) {

        printf("%d\n", current_number);
        next_number = current_number + old_number;

        old_number = current_number;
        current_number = next_number;
    }
    return (0);
}
