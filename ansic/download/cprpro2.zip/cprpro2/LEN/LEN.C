/********************************************************
 * Pytanie brzmi:						         *
 *	Dlaczego ten program zawsze stwierdza, ze	         *
 *	dlugosc dowolnego lancucha ma wartosc 0?	 	   *
 *							               *
 * Ponizej utworzono przykladowa funkcje main.   	   *
 * Jej zadaniem bedzie wczytanie lancucha, a nastepnie  *
 * wyswietlenie jego dlugosci.		               *
 ********************************************************/
#include <stdio.h>

/********************************************************
 * Funkcja length -- oblicza dlugosc lancucha           *
 *                                                      *
 * Parametry:                                           *
 *  string - lancuch, ktorego dlugosc                   * 
 *  zostanie obliczona                                  *
 *                                                      *
 * Wartosc zwracana:                                    *
 *      dlugosc lancucha                                *
 ********************************************************/
int  length(char string[])
{
    int             index;      /* indeks wewnatrz lancucha */
    /*
     * Petla jest wykonywana do momentu osiagniecia konca lancucha
    */
    for (index = 0; string[index] != '\0'; ++index)
        /* nic nie robi */
    return (index);
}

int main()
{
     char line[100];	/* dane wprowadzone przez uzytkownika */

     while (1) {
        printf("Wpisz tekst:");
        fgets(line, sizeof(line), stdin);

	printf("Dlugosc wynosi (lacznie ze znakiem nowego wiersza) : %d\n", length(line));
    }
}
