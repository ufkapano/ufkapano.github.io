/*-*/
/********************************************************
 * Nazwa:						              *
 *	length						        *
 * 							              *
 * Cel:						              *
 *	Okresla dlugosc wiersza			              *
 *							              *
 * Zastosowanie:						        *
 *	Po uruchomieniu wprowadz lancuch, a zostanie      *
 *    okreslona jego dlugosc.		                    *
 *							              *
 * Ograniczenia						        *
 *	Lancuch nie moze przekroczyc dlugosci 99 znakow	  *
 ********************************************************/
/*+*/
#include <string.h>
#include <stdio.h>

char line[100];	/* tekst wprowadzony z klawiatury */

int main()
{
    printf("Wpisz tekst: ");
    fgets(line, sizeof(line), stdin);

    printf("Dlugosc tekstu wynosi: %d\n", strlen(line));
    return (0);
}
