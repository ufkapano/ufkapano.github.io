#include <stdio.h>

/**********************************************************
 * Funkcja trojkat -- oblicza pole powierzchni trojkata   *
 *                                                        *
 * Parametry:                                             *
 *   width -- szerokosc trojkata                          *
 *   height -- wysokosc trojkata                          *
 *                                                        *
 * Wartosc zwracana:                                      *
 *   pole powierzchni trojkata                            *
 *********************************************************/
float triangle(float width, float height)
{
    float area;     /* pole powierzchni trojkata */

    area = width * height / 2.0;
    return (area);
}
