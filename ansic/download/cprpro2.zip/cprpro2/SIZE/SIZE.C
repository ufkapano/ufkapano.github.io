/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego program oblicza nieprawidlowa wartosc    *
 *	zmiennej "size?"						  *
 ********************************************************/
/*+*/
#include <stdio.h>

#define SIZE    10;
#define FUDGE   SIZE -2;
int main()
{
    int size;/* rozmiar rzeczywiscie stosowany */
    
    size = FUDGE;
    printf("Rozmiar ma wartosc %d\n", size);
    return (0);
}
