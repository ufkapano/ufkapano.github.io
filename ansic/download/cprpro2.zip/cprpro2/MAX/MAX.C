/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego ponizszy program w momencie kompilacji   *
 *	generuje ostrzezenie o nastepujacej tresci:	  *
 *	"czy zmienna counter moze byc uzyta przed         *
 *    jej inicjalizacja ?"		                    *
 *							              *
 *	Pomimo wszystko ta zmienna zostanie zastosowana   *
 *    w petli for, czy nie tak jest?	              *
 ********************************************************/
/*+*/
/* uwaga: spacje sa BARDZO wazne */

#include <stdio.h>

#define MAX =10

int main()
{
    int  counter;

    for (counter =MAX; counter > 0; --counter)
        printf("Czesc\n");

    return (0);
}
