/*-*/
/**********************************************************
 * Program:						                *
 *	Total						                *
 *							                *
 * Cel:						                *
 *	Wyznacza sume liczb znajdujacych sie na liscie.	    *
 *							                *
 * Zastosowanie:						          *
 *	Uruchom program.  Wprowadzaj jednoczesnie jedna     *
 *	liczbe.  Po osiagnieciu konca listy wprowadz 0, aby *
 *    zamknac program.				                *
 **********************************************************/
/*+*/
#include <stdio.h>
char  line[100];  /* zmienna przechowujaca dane wejsciowe */
int   total;  	/* suma dotychczas dodanych wartosci ciagu  */
int   item;   	/* nastepna pozycja, ktora zostanie dodana do listy */

int main()
{
    total = 0;
    while (1) {
        printf("Aby dodac wpisz znak # \n");
        printf("  lub w celu zatrzymania wpisz 0:");

        fgets(line, sizeof(line), stdin);
        sscanf(line, "%d", &item);

        if (item == 0)
            break;

        total += item;
        printf("Suma: %d\n", total);
    }
    printf("Suma koncowa wynosi: %d\n", total);
    return (0);
}
