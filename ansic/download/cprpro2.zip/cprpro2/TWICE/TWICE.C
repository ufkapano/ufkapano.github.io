/*-*/
/********************************************************
 * Nazwa:						              *
 *	print terms				                    *
 *							              *
 * Zastosowanie:						        *
 *	Po uruchomieniu programu zostanie wyswietlonych   *
 *     kilka prostych wynikow.		              *
 *							              *
 * Cel:						              *
 *	Demonstruje wyswietlanie wynikow prostych	        *
 *	rownan.					              *
 ********************************************************/
/*+*/
#include <stdio.h>

int term;       /* zmienna zastosowana w dwoch wyrazeniach */
int main()
{
    term = 3 * 5;
    printf("Dwa razy %d wynosi %d\n", term, 2*term);
    printf("Trzy razy %d wynosi %d\n", term, 3*term);
    return (0);
}
