/********************************************************
 * Rysunek 6.2.  Przyklad niepoprawnego programu.       *
 ********************************************************/
#include <stdio.h>
#include <stdlib.h>
int   g, l, h, c, n;
char  line[80];
int main()
{
    while (1) {
        /*na niby*/
        g = rand() % 100 + 1;
        l = 0;
        h = 100;
        c = 0;
        while (1) {
            printf("Wartosci graniczne %d - %d\n", l, h);
            printf("Wartosc[%d]? ", c);
            ++c;
            fgets(line, sizeof(line), stdin);
            sscanf(line, "%d", &n);
            if (n == g)
                break;
            if (n < g)
                l = n;
            else
                h = n;
        }
        printf("Sukces\n");
    }
    return (0);
}
