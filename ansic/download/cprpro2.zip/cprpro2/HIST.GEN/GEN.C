/*********************************************************
 * gen -- Generuje mnostwo losowych danych		   *
 *							               *
 * Zastosowanie:						         *
 *	gen						               *
 *							               *
 * Wyswietla 500 wierszy zawierajacych liczby od 1 do 40 *
 *********************************************************/
#include <stdlib.h>
#include <stdio.h>

const int MAX_LINES = 500;	/* Ilosc wierszy do zapisania */
const int MAX = 40;		/* Maksymalna ilosc */
int main()
{
    int index;	/* indeks petli */

    for (index = 0; index < MAX_LINES; ++index) {
       int number;	/* losowa liczba */

       number = rand();
       printf("%d\n", (number % (MAX-1)) +1);
    }
    return (0);
}

