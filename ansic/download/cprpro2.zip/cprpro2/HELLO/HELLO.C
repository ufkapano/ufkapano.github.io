#include <stdio.h>
int main()
{
    printf("Witaj swiecie\n");
    return (0);
}
