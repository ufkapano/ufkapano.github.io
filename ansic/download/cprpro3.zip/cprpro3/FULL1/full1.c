/*-*/
/********************************************************
 * Nazwa:						              *
 *	full name (V1)					        *
 *							              *
 * Cel:						              *
 *	Pobiera imie i nazwisko, a nastepnie je wyswietla.*							*
 * Zastosowanie:						        *
 *	Uruchom program.				              *
 *	Podaj imie.				                    *
 *	Podaj nazwisko.			                    *
 *	Zostanie wyswietlony wynik.			   	  *
 *							              *
 * BLAD: Program zawiera blad, ktory powoduje, ze imie  * 
 *	 i nazwisko sa umieszczane w oddzielnym wierszu.  *
 ********************************************************/
/*+*/
#include <stdio.h>
#include <string.h>

char first[100];        /* imie wspolpracownika */
char last[100];         /* jego nazwisko */

/* Imie i nazwisko wspolpracownika (po polaczeniu) */
char full[200];         

int main() {
    printf("Wpisz imie: ");
    fgets(first, sizeof(first), stdin);

    printf("Wpisz nazwisko: ");
    fgets(last, sizeof(last), stdin);

    strcpy(full, first);
    strcat(full, " ");
    strcat(full, last);

    printf("Imie i nazwisko brzmi: %s\n", full);
    return (0);
}
