/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego ponizszy program wyswietla cos takiego?: *
 *	"Wynikiem operacji 1/3 jest 0.0" ?			  *
 ********************************************************/
/*+*/
#include <stdio.h>

float answer;	/* zmienna przechowujaca wynik obliczen */

int main()
{
    answer = 1/3;
    printf("Wynikiem operacji 1/3 jest %f\n", answer);
    return (0);
}
