/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego 2+2=5986?				        *
 *	(Uzyskane wyniki moga sie roznic.)			  *
 ********************************************************/
/*+*/
#include <stdio.h>

/* zmienna przechowujaca wynik obliczen */
int answer;

int main()
{
    answer = 2 + 2;

    printf("Zmienna answer ma wartosc %d\n");
    return (0);
}
