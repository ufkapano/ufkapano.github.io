/*-*/
/********************************************************
 * Nazwa:						              *
 *	double						        *
 *							              *
 * Cel:						              *
 *	Demonstracja wczytywania liczby		        *
 *							              *
 * Zastosowanie:						        *
 *	Uruchom program.				              *
 *	Wprowadz liczbe.					        *
 *	Zostana wyswietlone wyniki.			    	  *
 *							              *
 * Uwagi:						              *
 *	Wprowadzane dane nie sa sprawdzane.		        *
 ********************************************************/
/*+*/
#include <stdio.h>
char  line[100];   /* tekst wczytany z konsoli */
int   value;       /* wartosc do podwojenia */

int main()
{
    printf("Podaj wartosc: ");

    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d", &value);

    printf("Dwukrotna wartoscia %d jest %d\n", value, value * 2);
    return (0);
}
