/*-*/
/**********************************************************
 * Nazwa: Triangle					          *
 *							                *
 * Cel: Oblicza pole powierzchni trzech trojkatow.	    *
 *							                *
 * Zastosowanie: Po uruchomieniu program wyswietli wynik. *
 **********************************************************/
/*+*/

#include <stdio.h>

/**********************************************************
 * Funkcja trojkat -- oblicza pole powierzchni trojkata   *
 *                                                        *
 * Parametry:                                             *
 *   width -- szerokosc trojkata                          *
 *   height -- wysokosc trojkata                          *
 *                                                        *
 * Wartosc zwracana:                                      *
 *   pole powierzchni trojkata                            *
 *********************************************************/
float triangle(float width, float height)
{
    float area;     /* pole powierzchni trojkata */

    area = width * height / 2.0;
    return (area);
}

int main()
{
    printf("Trojkat #1 %f\n", triangle(1.3, 8.3));
    printf("Trojkat #2 %f\n", triangle(4.8, 9.8));
    printf("Trojkat #3 %f\n", triangle(1.2, 2.0));
    return (0);
}


