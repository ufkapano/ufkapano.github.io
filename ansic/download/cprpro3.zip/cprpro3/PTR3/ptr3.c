/*-*/
/************************************************************
 * Program: Array initialization			            *
 *							                  *
 * Cel: Prezentacja inicjalizacji tablicy.		      *
 *							                  *
 * Zastosowanie: Po uruchomieniu programu spojrz na wyniki. *
 *							                  *
 * Uwaga: Program podobny do swojej poprzedniej wersji,	*
 *	poza faktem zastosowania zamiast indeksowania tablicy *
 *    arytmetyki wskaznikowej.	                        *
 ************************************************************/
/*+*/
#include <stdio.h>

int array[] = {4, 5, 8, 9, 8, 1, 0, 1, 9, 3};
int *array_ptr;

int main()
{
    array_ptr = array;

    while ((*array_ptr) != 0)
        ++array_ptr;

    printf("Ilosc elementow przed wystapieniem wartosci zero %d\n",
                  array_ptr - array);
    return (0);
}
