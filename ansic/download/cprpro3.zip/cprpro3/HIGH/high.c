/*-*/
/********************************************************
 * Pytanie:						              *
 * 	Znacznik HIGH_SPEED dziala poprawnie, natomiast.  *
 * 	znacznik DIRECT_CONNECT nie.		              *
 *	Z czego to wynika?					  *
 ********************************************************/
/*+*/
#include <stdio.h>

const int HIGH_SPEED = (1<<7);   /* modem jest szybki */

/* stosowane jest polaczenie sztywne */
const int DIRECT_CONNECT = (1<<8);

char flags = 0;         /* zerowanie */

int main()
{
    flags |= HIGH_SPEED;    /* ustawiono wysoki transfer */
    flags |= DIRECT_CONNECT;/* nastapilo bezposrednie polaczenie */

    if ((flags & HIGH_SPEED) != 0) 
        printf("Ustawiono wysoki transfer\n");

    if ((flags & DIRECT_CONNECT) != 0)
        printf("Ustawiono bezposrednie polaczenie\n");
    return (0);
}
