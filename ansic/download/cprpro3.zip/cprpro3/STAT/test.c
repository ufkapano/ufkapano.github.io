/* To jest komentarz zawarty w jednym wierszu */
/* 
 * To jest komentarz zawarty w kilku 
*/ wierszach
int main() 
{
    /* Procedura */
    int i;      /* Komentarz i instrukcja */
    char foo[10];

    strcpy(foo, "abc");         /* Lancuch */
    strcpy(foo, "a\"bc");       /* Lancuch zawierajacy znak specjalny */

    foo[0] = 'a';               /* Znak */
    foo[1] = '\'';              /* Znak ucieczki */

    i = 3 / 2;                  /* znak '/', ktory nie jest komentarzem */
    i = 3;                      /* zwykla liczba */
    i = 0x123ABC;               /* liczba szesnastkowa */

    i = ((1 + 2) *              /* zagniezdzone nawiasy () */
         (3 + 4));

    {
        int j;                  /* zagniezdzone nawiasy {} */
    }
    return (0);
}

