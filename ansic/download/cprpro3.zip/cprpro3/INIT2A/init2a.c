/*-*/
/************************************************************
 * Nazwa: Double						            *
 *							                  *
 * Cel: Wyswietla liczby i ich dwukrotnosc.	            *
 *							                  *
 * Zastosowanie: Aby uzyskac tabele zawierajaca dwukrotnosc *
 * liczb uruchom program.			                  *
 ************************************************************/
/*+*/
int data[10];    /* okreslone dane */
int twice[10];    /* dwukrotna ilosc danych */
int main()
{
    int index;   /* indeks danych */

    for (index = 0; index < 10; ++index) {
        data[index] = index;
        twice[index] = index * 2;
    }
    return (0);
}
