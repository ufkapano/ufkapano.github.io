/*-*/
/**********************************************************
 * Pytanie:						                *
 *	Dlaczego ponizszy program wyswietla komunikat	    * 
 *	"Nie jestes nic winien" nawet wtedy, gdy tak nie jest? *
 **********************************************************/
/*+*/
#include <stdio.h>
char  line[80];         /* zmienna przechowujaca dane wejsciowe */
int   balance_owed;     /* kwota zaleglosci */

int main()
{
    printf("Wpisz kwote zaleglosci w zlotych:");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d", &balance_owed);

    if (balance_owed = 0)
        printf("Nie jestes nic winien.\n");
    else
        printf("Jestes winien %d zlotych.\n", balance_owed);

    return (0);
}
