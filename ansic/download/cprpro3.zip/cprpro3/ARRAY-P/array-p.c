/*-*/
/***********************************************************
 * Nazwa: Address Demo					           *
 *							                 *
 * Cel: Prezentuje sposob, w jaki jest laczona ze soba     *
 * arytmetyka wskaznikowa i adresowanie tablicy.	     *
 *							                 *
 * Zastosowanie: Po uruchomieniu programu spojrz na wyniki.*
 ***********************************************************/
/*+*/
#include <stdio.h>

#define ARRAY_SIZE 10   /* Ilosc znakow w tablicy */
/* Tablica do wyswietlenia */
char array[ARRAY_SIZE] = "0123456789";   

int main()
{
    int index;  /* Indeks tablicy */

    for (index = 0; index < ARRAY_SIZE; ++index) {
        printf("&array[index]=0x%p (array+index)=0x%p array[index]=0x%x\n",
            &array[index], (array+index), array[index]);
    }
    return (0);
}
