/*-*/
/********************************************************
 * Program: ADD5 -- Dodaje 5 liczb.			        *
 *							              *
 * Zastosowanie:						        *
 *	Po uruchomieniu programu wprowadz 5 liczb, a      *
 *    zostanie wyznaczona ich suma.	                    *
 ********************************************************/
/*+*/
#include <stdio.h>

int total;      /* suma wszystkich liczb */
int current;    /* aktualna wartosc podana przez uzytkownika */
int counter;    /* licznik petli while */

char line[80];  /* zmienna przechowujaca dane wejsciowe */

int main() {
    total = 0;

    counter = 0;
    while (counter < 5) {
        printf("Jak liczba? ");

        fgets(line, sizeof(line), stdin);
        sscanf(line, "%d", &current);
        total += current;

        ++counter;
    }
    printf("Suma calkowita wynosi: %d\n", total);
    return (0);
}
