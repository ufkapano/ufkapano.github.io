/*-*/
/*********************************************************************
 * Pytanie:						                           * 
 *	Dlaczego program wyswietla wynik:		                     *
 *							                           *
 *	Stopnie w skali Celsjusza:101 Stopnie w skali Fahrenheita:213  *
 *							                           *
 *	i nic poza tym?				                           *
 *********************************************************************/
/*+*/
#include <stdio.h>
/*
 * Program generuje wykres konwersji stopni w skali Celsjusza na stopnie 
 * w skali Fahrenheita dla wartosci od 0 do 100.
 *    
 */

/* Aktualna wartosc temperatury w skali Celsjusza */
int celsius;
int main() {
    for (celsius = 0; celsius <= 100; ++celsius);
        printf("Stopnie w skali Celsjusza:%d Stopnie w skali Fahrenheita:%d\n",
            celsius, (celsius * 9) / 5 + 32);
    return (0);
}
