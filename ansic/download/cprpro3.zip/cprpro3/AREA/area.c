#include <stdio.h>

float area(width, height)
int width;
float height;
{
    return (width * height);
}

int main()
{
    float size = area(3.0, 2);

    printf("Pole powierzchni wynosi %f\n", size);
    return (0);
}
