/*-*/
/********************************************************
 * Nazwa: Square generator				        *
 *							              * 
 * Cel: Generuje tablice kwadratow liczb.			  *
 *							              *
 * Zastosowanie: Aby wygenerowac tabele uruchom program.*
 *							              *
 * Uwagi: Wskutek bledu	preprocesora nie uzyskamy       *
 *	spodziewanego wyniku.					  *
 ********************************************************/
/*+*/
#include <stdio.h>
#define SQR(x) (x * x)

int main()
{
    int counter;    /* licznik petli */

    for (counter = 0; counter < 5; ++counter) {
        printf("x %d, liczba x podniesiona do kwadratu daje %d\n",
            counter+1, SQR(counter+1));
    }
    return (0);
}
