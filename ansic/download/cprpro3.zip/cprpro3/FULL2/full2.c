/*-*/
/********************************************************
 * Nazwa:						              *
 *	full name (V2)					        *
 *							              *
 * Cel:						              *
 *	Pobiera imie i nazwisko, a nastepnie je wyswietla.*							*
 * Zastosowanie:						        *
 *	Uruchom program.				              *
 *	Podaj imie.				                    *
 *	Podaj nazwisko.			                    *
 *	Zostanie wyswietlony wynik.			   	  *
 *							              *
 * Uwaga: Ta wersja nie zawiera bledu, ktory wystepuje  *
 *	w programie 4_6.c                                 *
 ********************************************************/
/*+*/
#include <stdio.h>
#include <string.h>

char first[100];        /* imie wspolpracownika */
char last[100];         /* jego nazwisko */

/* Imie i nazwisko wspolpracownika (po polaczeniu)*/
char full[100];         

int main() {
    printf("Wpisz imie: ");
    fgets(first, sizeof(first), stdin);
    /* obcina ostatni znak */
    first[strlen(first)-1] = '\0';

    printf("Wpisz nazwisko: ");
    fgets(last, sizeof(last), stdin);
    /* obcina ostatni znak */
    last[strlen(last)-1] = '\0';

    strcpy(full, first);
    strcat(full, " ");
    strcat(full, last);

    printf("Imie i nazwisko brzmi: %s\n", full);
    return (0);
}
