/*-*/
/*********************************************************
 * Nazwa: Divide error.					         *
 *							               *
 * Program zawiera blad dzielenia przez zero.		   *
 *							               *
 * W celu wyizolowania problemu zostaly dodane wywolania *
 * funkcji printf                                        *
 *********************************************************/
/*+*/
#include <stdio.h>
int main()
{
    int i,j;    /* dwie losowe liczby calkowite */

    i = 1;
    j = 0;

    printf("Poczatek\n");
    fflush(stdout);

    printf("Przed operacja dzielenia...");
    fflush(stdout);

    i = i / j;  /* blad dzielenia przez zero */

    printf("Koniec\n");
    fflush(stdout);
    return(0);
}
