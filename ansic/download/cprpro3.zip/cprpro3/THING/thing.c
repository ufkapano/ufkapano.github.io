/*-*/
/********************************************************
 * Nazwa: Pointer demo					        *
 *							              *
 * Cel: Prezentacja wykorzystania wskaznikow.		  *
 *							              *
 * Zastosowanie: Program jest nieprzydatny.  		  *
 ********************************************************/
/*+*/
#include <stdio.h>
int main()
{
    int   thing_var;  /* definicja zmiennej thing_var */
    int  *thing_ptr;  /* definicja wskaznika do zmiennej thing_var */

    thing_var = 2;      /* przypisanie wartosci zmiennej thing_var */
    printf("Zmienna thing_var ma wartosc %d\n", thing_var);

    thing_ptr = &thing_var; /* wskaznik wskazuje na zmienna thing_var */
    *thing_ptr = 3;     /* wskaznik thing_ptr wskazuje na zmienna thing_var, a wiec*/
                        /* jej wartosc wynosi teraz 3 */
    printf("Zmienna thing_var ma wartosc %d\n", thing_var);

    /* kolejne wywolanie funkcji printf */
    printf("Zmienna thing_var ma wartosc %d\n", *thing_ptr);
    return (0);
}
