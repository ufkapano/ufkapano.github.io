/*-*/
/********************************************************
 * Pytanie: 						        *
 * 	Program ten ma okreslac ilosc trojek i 	        *
 *	siodemek wystepujacych w danych, ale podaje       *
 *    nieprawidlowy wynik.  Dlaczego tak sie dzieje?    *
 ********************************************************/
/*+*/
#include <stdio.h>
char line[100];     /* dane wejsciowe */
int seven_count;    /* ilosc siodemek w danych */
int data[5];        /* dane zawierajace liczbe 3 i 7 */
int three_count;    /* ilosc trojek w danych */
int index;  	    /* indeks danych */

int main() {

    seven_count = 0;
    three_count = 0;
    printf("Podaj 5 liczb\n");
    fgets(line, sizeof(line), stdin);
    sscanf(line, "%d %d %d %d %d", 
        &data[1], &data[2], &data[3],
        &data[4], &data[5]);

    for (index = 1; index <= 5; ++index) {

        if (data[index] == 3)
            ++three_count;

        if (data[index] == 7)
	    ++seven_count;
    }
    printf("Trojek: %d Siodemek: %d\n", 
            three_count, seven_count);
    return (0);
}
