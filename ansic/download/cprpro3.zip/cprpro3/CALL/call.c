/*-*/
/*****************************************************************
 * Nazwa: parameter					                 *
 *							                       *
 * Cel: Prezentacja zastosowania wskaznikow i                    *
 * przekazywania parametrow.		                             *
 *							                       *
 * Zastosowanie: Nieprzydatny, przeanalizuj zawartosc kodu	     *
 *	lub za pomoca debuggera uruchom program w trybie krokowym. *
 *****************************************************************/
/*+*/
#include <stdio.h>
void inc_count(int *count_ptr)
{
    ++(*count_ptr);
}

int main()
{
    int  count = 0;     /* licznik petli */

    while (count < 10)
        inc_count(&count);

    return (0);
}
