/*-*/
/**********************************************************
 * Nazwa: Square generator				          *
 *							                *
 * Cel: Generuje tablice kwadratow liczb.			    *
 *							                *
 * Zastosowanie: Aby wygenerowac tabele uruchom program.  *
 *							                *
 * Uwagi: Poprawiona wersja poprzedniego programu.	    *
 **********************************************************/
/*+*/
#include <stdio.h>
#define SQR(x) ((x) * (x))

int main()
{
    int counter;    /* licznik petli */

    counter = 0;

    while (counter < 5)
        printf("kwadrat liczby x %d daje %d\n", counter, SQR(++counter));

    return (0);
}
