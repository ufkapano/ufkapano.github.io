/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego jest wyswietlany nieprawidlowy wynik?    *
 ********************************************************/
/*+*/
#include <stdio.h>

float result;	/* wynik operacji dzielenia */

int main()
{
    result = 7.0 / 22.0;

    printf("Wynikiem jest %d\n", result);
    return (0);
}
