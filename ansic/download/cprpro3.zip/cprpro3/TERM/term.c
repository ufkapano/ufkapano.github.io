/*-*/
/********************************************************
 * Nazwa:						              *
 *	term -- wyznacza wartosc trzech elementow	        *
 *							              *
 * Cel:						              *
 *	demonstruje zastosowanie zmiennych.		        *
 *							              * 
 * Uwagi:						              *
 *	Program do celow demonstracyjnych. Nie robi       * 
 *    nic konkretnego.					        *
 ********************************************************/
/*+*/
int term;       /* element uzyty w dwoch wyrazeniach */
int term_2;     /* element pomnozony przez 2 */
int term_3;     /* element pomnozony przez 3 */
int main()
{
    term = 3 * 5;
    term_2 = 2 * term;
    term_3 = 3 * term;
    return (0);
}
