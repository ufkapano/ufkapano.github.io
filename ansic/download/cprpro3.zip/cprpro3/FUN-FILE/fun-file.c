/*-*/
/***********************************************************
 * Pytanie:						                 *
 *	Ponizszy program nie potrafi otworzyc pliku	     *
 *	niezaleznie od jego nazwy. Czym jest to spowodowane? *
 ***********************************************************/
/*+*/
#include <stdio.h>
#include <stdlib.h>	

int main()
{
    char            name[100];  /* nazwa szukanego pliku */
    FILE           *in_file;    /* plik wejsciowy */

    printf("Jaka jest nazwa pliku? ");
    fgets(name, sizeof(name), stdin);

    in_file = fopen(name, "r");
    if (in_file == NULL) {
        fprintf(stderr, "Plik nie mogl byc otwarty\n");
        exit(8);
    }
    printf("Plik zostal znaleziony\n");
    fclose(in_file);
    return (0);
}
