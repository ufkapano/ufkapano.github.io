/*-*/
/********************************************************
 * Nazwa:						              *
 *	print3						        *
 *							              *
 * Cel:						              *
 *	Celem demonstracji wyswietlania znakow	        *
 *	najpierw wyswietla 3 znaki, a nastepnie te same   *
 *    znaki, ale w odwrotnej kolejnosci.			  *
 *							              *
 * Zastosowanie:						        *
 *	Uruchom program i sprawdz wynik.			  *
 ********************************************************/
/*+*/
#include <stdio.h>

char char1;     /* pierwszy znak */
char char2;     /* drugi znak */
char char3;     /* trzeci znak */

int main()
{
    char1 = 'A';
    char2 = 'B';
    char3 = 'C';
    printf("Znaki %c%c%c sa odwroceniem znakow %c%c%c\n",
        char1, char2, char3,
        char3, char2, char1);
    return (0);
}
