#define BIG_NUMBER 10 ** 10

main()
{
    /* indeks stosowany przy obliczeniach */
    int   index;                

    index = 0;

    /* w nastepnym wierszu wystepuje blad skladni */
    while (index < BIG_NUMBER) {
        index = index * 8;
    }
    return (0);
}
