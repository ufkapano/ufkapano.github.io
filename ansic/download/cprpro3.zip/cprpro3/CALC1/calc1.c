/*-*/
/***********************************************************
 * Nazwa: Calculator (Wersja 0 -- prototyp)		     *
 *							                 *
 * Cel:						                 *
 *	Dziala podobnie jak kalkulator 4-funkcyjny.	     *
 *							                 *  
 * Zastosowanie:						           *
 *	Uruchom program.				                 *
 *	Wprowadz operator (+ - * /) i liczbe.	           *
 *	Operacja zostanie wykonana na aktualnym wyniku,	     *
 *	po czym zostanie wyswietlony nowy wynik.		     *
 *							                 *
 * Uwaga:						                 *
 *	Jest to pierwsza wersja programu.                    *
 *	Na razie wykonywana jest tylko operacja dodawania,   *
 *	ale z powodu bledu w programie nawet ona nie dziala. *
 ***********************************************************/
/*+*/
#include <stdio.h>
char  line[100];/* zmienna przechowujaca dane wejsciowe */
int   result;   /* wynik obliczen */
char  operator; /* operator podany przez uzytkownika */
int   value;    /* wartosc podana za operatorem */

int main()
{
    result = 0; /* inicjalizacja zmiennej result */

    /* petla wykonywana w nieskonczonosc */
    /* (lub do momentu wykonania instrukcji break) */
    while (1) {
        printf("Wynik: %d\n", result);

        printf("Podaj operator i liczbe: ");
        fgets(line, sizeof(line), stdin);
        sscanf(line, "%c %d", &operator, &value);

        if (operator = '+') {
            result += value;
        } else {
            printf("Nieprawidlowy typ operatora %c\n", operator);
        }
    }
}
