/*-*/
/********************************************************
 * Pytanie:						              *
 *	Dlaczego ponizszy program wyswietla wynik		  *
 *	Nazwa pliku: @$@#$#@$@				        *
 *	(Uzyskane wyniki moga byc inne)?			  *
 ********************************************************/
/*+*/
#include <stdio.h>
#include <string.h>

/********************************************************
 * tmp_name -- zwraca nazwe pliku tymczasowego          *
 *							               *
 * Przy kazdym wywolaniu tej funkcji, zostanie zwrocona *
 * inna nazwa pliku.						   *
 *							               *
 * Wartosc zwracana						   *
 * 	Wskaznik do nowej nazwy pliku.			   *
 ********************************************************/
char *tmp_name(void)
{
    char name[30];	/* Generowana nazwa */
    static int sequence = 0;	/* Kolejna liczba dla ostatniej cyfry */

    ++sequence;	/* Przesuniecie do nastepnej nazwy pliku */

    strcpy(name, "tmp");

    /* ale dla kolejnej cyfry */
    name[3] = sequence + '0';

    /* koniec lancucha */
    name[4] = '\0';

    return(name);
}

int main()
{
    char *tmp_name(void);	/* pobranie nazwy pliku tymczasowego */

    printf("Nazwa pliku: %s\n", tmp_name());
    return(0);
}
