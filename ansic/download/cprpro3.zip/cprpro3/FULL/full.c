/*-*/
/*************************************************************
 * Nazwa:						                   *
 *	concat						             *
 *							                   *
 * Cel:						                   *
 *	Prezentacja operacji laczenia lancuchow przy	       *
 *	pomocy funkcji strcat.						 * 
 *							                   *
 * Zastosowanie:						             *
 * 	Uruchom program i sprawdz wyswietlone imie i nazwisko. *
 *							                   *
 *************************************************************/
/*+*/
#include <string.h>
#include <stdio.h>

char first[100];        /* imie */
char last[100];         /* nazwisko */
char full_name[200];    /* imie i nazwisko */

int main()
{
    strcpy(first, "Piotr");       /* inicjalizacja zmiennej first */
    strcpy(last, "Nowak");     /* inicjalizacja zmiennej last */

    strcpy(full_name, first);     /* full = "Piotr" */
    /* Uwaga: strcat nie strcpy */
    strcat(full_name, " ");       /* full = "Piotr " */
    strcat(full_name, last);      /* full = "Piotr Nowak� */

    printf("Imie i nazwisko: %s\n", full_name);
    return (0);
}
