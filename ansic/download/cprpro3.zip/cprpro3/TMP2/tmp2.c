/*-*/
/**********************************************************
 * Pytanie:						                *
 *	Problem z ostatniego pytania zostal usuniety, ale   *
 *	pojawil sie kolejny.  Co ponizszy program wyswietla *
 *    i dlaczego?				                      *
 **********************************************************/

/*+*/
#include <stdio.h>
#include <string.h>

/********************************************************
 * tmp_name -- zwraca nazwe pliku tymczasowego	   *
 *							   *
 * Za kazdym wywolaniem tej funkcji jest zwracana	   *
 * nowa nazwa pliku.					   *
 *							   *
 * Ostrzezenie: Powinno pojawic sie tutaj ostrzezenie,  *
 *	ale jesli je wstawimy, wtedy tym samym          *
 *       odpowiemy na pytanie.		                  *
 *							   *
 * Wartosc zwracana					   *
 * 	Wskaznik do nazwy nowego pliku.		   *
 ********************************************************/
char *tmp_name(void)
{
    static char name[30];	/* Generowana nazwa */
    static int sequence = 0;	/* Numer kolejny dla ostatniej cyfry */

    ++sequence;	/* Przejscie do nastepnej nazwy pliku */

    strcpy(name, "tmp");

    /* ale dla kolejnej cyfry */
    name[3] = sequence + '0';

    /* znak konca lancucha */
    name[4] = '\0';

    return(name);
}

int main()
{
    char *tmp_name(void);	/* pobranie nazwy pliku tymczasowego */
    char *name1;		       /* nazwa pliku tymczasowego */
    char *name2;		       /* nazwa pliku tymczasowego */

    name1 = tmp_name();
    name2 = tmp_name();

    printf("Nazwa pliku: %s\n", name1);
    printf("Nazwa pliku: %s\n", name2);
    return(0);
}
