/*-*/
/********************************************************
 * Program:						              *
 *	Total						              *
 *							              *
 * Cel:						              *
 *	Wyznacza sume liczb znajdujacych sie na liscie.	  *
 *	Nie uwzglednia liczb ujemnych.		        *
 *							              *
 * Zastosowanie:						        *
 *	Uruchom program.  Wprowadzaj jednoczesnie jedna   *
 *	liczbe.  Po osiagnieciu konca listy wprowadz 0,   *
 *    aby zamknac program.			 	        *
 *							              *
 * 	Liczby ujemne sa liczone, ale nie sumowane	  *
 ********************************************************/
/*+*/
#include <stdio.h>
char  line[100];   /* zmienna przechowujaca dane wejsciowe */
int   total;       /* suma dotychczas dodanych wartosci ciagu */
int   item;        /* nastepna pozycja, ktora zostanie dodana do listy */
int   minus_items; /* ilosc wartosci ujemnych */

int main()
{
    total = 0;
    minus_items = 0;

    while (1) {
        printf("Aby dodac wpisz znak #\n");
        printf("  lub w celu zatrzymania wpisz 0:");

        fgets(line, sizeof(line), stdin);
        sscanf(line, "%d", &item);

        if (item == 0)
            break;

        if (item < 0) {
            ++minus_items;
            continue;
        }
        total += item;
        printf("Suma: %d\n", total);
    }

    printf("Suma koncowa wynosi: %d\n", total);
    printf(",w tym zostalo pominietych %d wartosci ujemnych\n",
                   minus_items);
    return (0);
}
